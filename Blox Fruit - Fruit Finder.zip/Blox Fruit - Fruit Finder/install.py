pip install robloxpy
pip install requests
pip install browser_cookie3
